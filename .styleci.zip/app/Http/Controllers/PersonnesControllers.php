<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PersonnesControllers extends Controller
{
    //
    public function index(){
        $clients = DB::table('personne')
            ->select('*')
            ->where('statut','=',1)
            ->get()->toJson();
        return response($clients,200);

    }

    public function createClient(Request $request) {


        $nom = $request->input('nom');
        $prenoms = $request->input('prenoms');
        $telephone = $request->input('telephone');

        $data = array(

            'nom'=>$nom,
            'prenoms'=>$prenoms,
            'telephone'=>$telephone,

        );

        $clients = DB::table('personne')->insert($data);

        if ($clients){
            return response()->json($clients, 201);
        }

        else{
            return response()->json( null,400);

        }

    }


    public function updateClient(Request $request,$id) {
        $nom = $request->input('nom');
        $prenoms = $request->input('prenoms');
        $telephone = $request->input('telephone');

        $data = array(

            'nom'=>$nom,
            'prenoms'=>$prenoms,
            'telephone'=>$telephone,

        );

        $clients = DB::table('personne')->where('id_personne','=',$id)
            ->update($data);

        if ($clients){
            return response()->json($clients, 201);
        }

        else{
            return response()->json( null,400);

        }

    }

    public function deleteClient ($id) {
        $update = DB::table('personne')
            ->where('id_personne','=',$id)->update(array(
                'statut'=>2
            ));
        if ($update){
            return response()->json($update, 201);
        }
        else{
            return response()->json( null,400);

        }
    }
}
