<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CaisseControllers extends Controller
{
    //
    public function index(){
        $valeur_entre = DB::table('montant_paiement')->sum('montant_paiement.montant_paiement');
        $entree = number_format($valeur_entre,'0',',',' ');
        $valeur_sortie = DB::table('sortie_caisse')->sum('montant_sortie_caisse');
        $sortie = number_format($valeur_sortie,'0',',',' ');
        $valeur_chiffre = DB::table('facture_entre')->sum('montant_facture_entre');
        $chiffre = number_format($valeur_chiffre,'0',',',' ');
        $data = array('entree'=>$entree,'sortie'=>$sortie, 'chiffres'=>$chiffre);
        return response()->json($data, 201);
    }

    public function sortir_caisse(Request $request){
        $personne = $request->input('personne');
        $libelle = $request->input('libelle');
        $date_sortie = $request->input('date_sortie');
        $observation = $request->input('observation');
        $montant =(float)$request->input('montant');

        $data = array(

            'id_personne'=>$personne,
            'libelle_sortie_caisse'=>$libelle,
            'montant_sortie_caisse'=>$montant,
            'date_sortie_caisse'=>$date_sortie,
            'observation'=>$observation,

        );

        $clients = DB::table('sortie_caisse')->insert($data);

        if ($clients){
            return response()->json($clients, 201);
        }

        else{
            return response()->json( null,400);

        }
    }

    public function entrer_caisse(Request $request){

        $libelle = $request->input('libelle');
        $date_facture = $request->input('date_facture');
        $code_facture = $request->input('code_facture');
        $montant =(float)$request->input('montant');


        $data = array(
            'libelle_facture_entre'=>$libelle,
            'montant_facture_entre'=>$montant,
            'date_facture_entre'=>$date_facture,
            'code_facture_entre'=>$code_facture,
        );

        $facture = DB::table('facture_entre')->insert($data);


        if ($facture){
            return response()->json(null, 201);
        }

        else{
            return response()->json( null,400);

        }
    }


    public function paiement(Request $request){
        $personne = $request->input('personne');
        $code_facture = $request->input('code_facture');
        $date_paiement =$request->input('date_paiement');
        $montant_paiement =(float)$request->input('montant_paiement');

        $data_paiement = array(
            'id_personne'=>$personne,
            'date_montant_paiement'=>$date_paiement,
            'code_facture_entre'=>$code_facture,
            'montant_paiement'=>$montant_paiement
        );

        $paiment = DB::table('montant_paiement')->insert($data_paiement);

        if ($paiment){
            return response()->json(null, 201);
        }

        else{
            return response()->json( null,400);

        }
    }


    public function listes_factures_entree($id){

        $listes_paiement = DB::table('montant_paiement')
            ->select('montant_paiement.*','facture_entre.*'
                ,DB::raw("SUM(montant_paiement.montant_paiement) as total_payer,(facture_entre.montant_facture_entre - SUM(montant_paiement.montant_paiement)) as reste_payer"))
            ->join('facture_entre','facture_entre.code_facture_entre','=','montant_paiement.code_facture_entre')
            ->where('montant_paiement.id_personne','=',$id)
            ->get()->toJson();

        return response($listes_paiement,200);
    }


    public function listes_sorties($id){

        $listes_paiement = DB::table('sortie_caisse')
            ->where('sortie_caisse.id_personne','=',$id)
            ->get();

        $info = DB::table('personne')
            ->where('id_personne','=',$id)
            ->first();
        $marge = array('listes_paiement'=>$listes_paiement,'info'=>$info);
        return response()->json($marge,200);
    }

    public function listes_versements($id){

        $listes_paiement = DB::table('montant_paiement')
            ->where('montant_paiement.code_facture_entre','=',$id)
            ->get();
        $info = DB::table('facture_entre')
            ->where('facture_entre.code_facture_entre','=',$id)
            ->first();
        $marge = array('listes_paiement'=>$listes_paiement,'info'=>$info);
        return response()->json($marge,200);
    }
}
